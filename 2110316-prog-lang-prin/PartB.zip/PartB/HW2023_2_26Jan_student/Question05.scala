object Question05 {

  def mergesort(l: List[Int]):List[Int] ={
    


  }


}
