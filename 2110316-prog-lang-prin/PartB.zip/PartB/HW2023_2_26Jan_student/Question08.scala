object Question08 {
 
  def maxAll(lists:List[List[Int]]) :List[Int] = {
    

    
  }

}
