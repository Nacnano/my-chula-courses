object Question09 {

  //val tape = List('C','H','A','R')

  def turingStep(f:Char => Char,tape:List[Char], n:Int): List[Char] ={
   
  }


}
