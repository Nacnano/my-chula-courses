object Question04 {
  def palindrome(l :List[Any]): Boolean ={



  }

  def main(args: Array[String]): Unit = {


  }

}
