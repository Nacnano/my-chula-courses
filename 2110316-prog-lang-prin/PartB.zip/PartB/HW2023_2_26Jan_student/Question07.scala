object Question07 {
  
  def myMap(f:Int => Int) (list:List[Int]) :List[Int] = {
  

  }


}
