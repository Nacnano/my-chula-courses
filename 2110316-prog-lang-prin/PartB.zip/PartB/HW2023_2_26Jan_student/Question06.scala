object Question06 {
  
  def myFilter(f:Int => Boolean) (list:List[Int]) :List[Int] = {
    
  }

}
